import Foundation

print("I have learned the following:")
print("What features make Swift a modern and safe language")
print("How to use the Swift REPL in Terminal")
print("How to use playgrounds to make writing Swift fun and simple")


print("My favorite song is The Saudi National Anthem ")
print(" Go fast for glory and highness ")
print(" Glorify the heaven's creator ")
print(" And raise the flag green ")
